import React, {useState} from "react";
import axios from "axios";

const Register = () => {
    const [formData, setFormData] = 
    useState({
        username: '',
        name: '',
        password:'',
        userImage: '',
        address: '',
        phone:''
    });

    const handleRegister = async (e) => {
        e.preventDefault();
        try{
            await axios.post('/register', formData);
            alert('User Register Successfully');
            window.location = '/login';
        }catch (error){
            alert (error.response.data.message);
        }
    };

    return(
        <>
          <form className="form-control" onSubmit={handleRegister}>
              <div className="mb-2">
                  <label>UserName</label>
                  <input type="text" placeholder="UserName" className="form-control" required onChange={(e)=> setFormData({
                    ...FormData,
                    username: e.target.value })} />
               </div>
               <div className="mb-2">
                  <label>Name</label>
                  <input type="text" placeholder="Name" className="form-control" required onChange={(e) => setFormData({
                    ...FormData, name:e.target.value
                  })}/>
               </div>
               <div className="mb-2">
                  <label>Password</label>
                  <input type="password" placeholder="Password" className="form-control" required onChange={(e) => setFormData({
                    ...FormData, password:e.target.value
                  })} />
               </div>
               <div className="mb-2">
                  <label>UserImage</label>
                  <input type="file" placeholder="UserImage" className="form-control" required onChange={(e) => setFormData({
                    ...FormData, userImage:e.target.value
                  })} />
               </div>
               <div className="mb-2">
                  <label>Address</label>
                  <input type="text" placeholder="Address" className="form-control" required 
                  onChange={(e) => setFormData({
                    ...FormData, address:e.target.value
                  })}/>
               </div>
               <div className="mb-2">
                  <label>Phone</label>
                  <input type="text" placeholder="Phone" className="form-control" required
                  onChange={(e) => setFormData({
                    ...FormData, phone:e.target.value
                  })} />
               </div>
               <button type="submit" className="btn btn-primary">Register</button>
          </form>
        </>
    )
}

export default Register;